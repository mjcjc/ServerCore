#include "..\Common.h"
#include "NetworkCore.h"

int main()
{
	
    NetworkCore server;

    server.Initialize();
    server.bindSock();
    server.listenSock();

    printf("[TCP ����] ����. ��Ʈ ��ȣ=%d\n", SERVERPORT);
    
    server.Run();
    server.closeSock();
	return 0;
}
