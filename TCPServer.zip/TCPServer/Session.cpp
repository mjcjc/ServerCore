#include "Session.h"
#include "NetworkCore.h"
#include "SocketUtils.h"
#include "PacketHeader.h"
#include "PacketType.h"
#include <atomic>

std::atomic<int> UserIdCount = 1;

Session::Session(SOCKET client_sock, sockaddr_in clientaddr, NetworkCore* server)
    : client_sock(client_sock), clientaddr(clientaddr), server(server)
{
}
void Session::Process()
{
    while (true)
    {
		PacketHeader header;

		if (!SocketUtils::RecvAll(client_sock, (char*)&header, sizeof(header)))
			break;

		if (header.size < sizeof(PacketHeader))
			break;

		if (header.size > BUFSIZE)
			break;

		int bodySize = header.size - sizeof(PacketHeader);
		char packet[BUFSIZE + 1] = {};

		memcpy(packet, &header, sizeof(header));

		if (!SocketUtils::RecvAll(client_sock, packet + sizeof(PacketHeader), bodySize))
			break;

		char* body = packet + sizeof(PacketHeader);
		body[bodySize] = '\0';


        switch (static_cast<PacketType>(header.type))
        {
        case PacketType::LOGIN_REQUEST:
        {
            if (state != SessionState::CONNECTED)
            {
                printf("[�α��� ����] �̹� �α��ε� �����Դϴ�.\n");
                break;
            }

            if (header.size != sizeof(LoginRequest))
            {
                printf("[�α��� ����] �߸��� ��Ŷ ũ���Դϴ�.\n");
                break;
            }

            const LoginRequest* loginPacket = reinterpret_cast<const LoginRequest*>(packet);
            size_t nicknameLength = strnlen_s(loginPacket->nickname, sizeof(loginPacket->nickname));
            LoginResponse response{};

            response.header.size = static_cast<uint16_t>(sizeof(LoginResponse));
            response.header.type = static_cast<uint16_t>(PacketType::LOGIN_RESPONSE);

            if (nicknameLength == 0 || nicknameLength >= sizeof(loginPacket->nickname))
            {
                response.success = 0;
                response.userId = 0;

                Send(
                    reinterpret_cast<const char*>(&response),
                    sizeof(response)
                );

                printf("[�α��� ����] �߸��� �г����Դϴ�.\n");
                break;
            }

            std::string requestedNickname(loginPacket->nickname,nicknameLength);

            if (!server->TrySetNickname(client_sock,requestedNickname))
            {
                response.success = 0;
                response.userId = 0;

                Send(reinterpret_cast<const char*>(&response),sizeof(response));

                printf("[�α��� ����] �̹� ��� ���� �г���: %s\n", requestedNickname.c_str());

                break;
            }

            userId = UserIdCount.fetch_add(1);
            state = SessionState::LOGIN;

            response.success = 1;
            response.userId = userId;

            if (!Send(reinterpret_cast<const char*>(&response), sizeof(response)))
            {
                printf("[����] �α��� ���� ���� ����\n");
                break;
            }

            printf("[�α��� ����] ID=%d, �г���=%s\n",userId, nickname.c_str()
            );

            break;
        }

        case PacketType::MESSAGE:
        {
            if (state != SessionState::LOGIN)
            {
                printf("[����] �α������� ���� ������ ä�� ��û\n");
                break;
            }
            printf("[���� ä��] %s: %s\n", nickname.c_str(), body);
            server->Broadcast(client_sock, packet, header.size);

            break;
        }

        default:
        {
            printf(
                "[����] �� �� ���� ��Ŷ Ÿ��: %d\n",
                header.type
            );

            break;
        }
        }
    }

	server->RemoveClient(client_sock);
    closesocket(client_sock);
    char addr[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &clientaddr.sin_addr, addr, sizeof(addr));

    printf("[TCP ����] Ŭ���̾�Ʈ ����: IP �ּ�=%s, ��Ʈ ��ȣ=%d\n",
        addr, ntohs(clientaddr.sin_port));

}

bool Session::Send(const char* packetData, int packetSize)
{
	std::lock_guard<std::mutex> lock(sendMutex);

	return SocketUtils::SendAll(
		client_sock,
		packetData,
		packetSize
	);
}
